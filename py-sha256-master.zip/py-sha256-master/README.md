## Experimental python implementation of SHA256


This Python implementation of the SHA256 follows the official publication http://csrc.nist.gov/publications/fips/fips180-4/fips-180-4.pdf

The goal of this code base is not to create a novel way of hashing or improve the speed of existing implementation.
The goal is to create human readable implementation (And we are not there yet.)
